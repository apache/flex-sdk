RESOURCES="../../../Assets/Locales/qa_QA"
BUNDLES="bundle1 bundle2 collections containers controls core effects formatters logging SharedResources skins states styles validators textLayout"

$SDK_DIR/bin/compc -library-path=$SDK_DIR/frameworks/libs -source-path=$RESOURCES -locale qa_QA -include-resource-bundles $BUNDLES -include-classes HaloColors MyCheckBoxIcon_qa_QA -o qa_QA_Resources.swc
